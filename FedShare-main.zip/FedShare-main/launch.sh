python main.py \
    --all_clients \
    --fed fedavg \
    --gpu 0 \
    --seed 3 \
    --sampling iid \
    --num_channels 3 \
    --dataset cifar
