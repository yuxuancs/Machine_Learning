tensorboard --logdir=runs --host=0.0.0.0 --port=$port
